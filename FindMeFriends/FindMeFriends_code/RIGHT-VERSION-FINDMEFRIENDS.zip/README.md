Team Name: Find Me Friends!

Members:
Yuli-Anne Rainville;
Deggan Farah;
Rolf Addoumie;
Shirina Huang;
Nikolas Kaern


Description of the product:

“FindMeFriends” is a Mobile Application that allows users to easily find friends near them. It’s meant to help people make friends in a new environment through live location sharing. Wanna meet someone new? Open the app, find an intriguing profile, walk up to them, and have a chat!



